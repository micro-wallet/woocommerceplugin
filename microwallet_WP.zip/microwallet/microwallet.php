<?php

/*
Plugin Name: Microwallet Payments - Microwallet WooCommerce Payment Gateway
Plugin URI: https://microwallet.co/
Description: Microwallet Payments - Microwallet Gateway allows you to accept payment through various cryptocurrency On your Woocommerce Powered Site.
Version: 1.0.0
Author: Microwallet
Author URI: https://microwallet.co/
License:           GPL-3.0+
License URI:       http://www.gnu.org/licenses/gpl-3.0.txt
WC tested up to: 4.6.1
Text Domain: microwallet
Domain Path: /languages
 */

if (!defined('ABSPATH')) {
    exit;
}

add_action('plugins_loaded', 'woocommerce_microwallet_init', 0);

function woocommerce_microwallet_init()
{
    if (!class_exists('WC_Payment_Gateway')) {
        return;
    }

    load_plugin_textdomain('microwallet', false, dirname(plugin_basename(__FILE__)) . '/languages/');

    /**
     * Gateway class
     */
    class WC_Microwallet_Gateway extends WC_Payment_Gateway
    {
        public function __construct()
        {
            global $woocommerce;

            $this->id = 'microwallet_gateway';
            $this->has_fields = false;
            $this->liveurl = 'https://microwallet.co/api/v3/';
            $this->notify_url = WC()->api_request_url('WC_Microwallet_Gateway');
            $this->method_title = 'Microwallet Gateway';
            $this->method_description = __('Microwallet Payment Gateway allows you to accept payment through various cryptocurrency.', 'microwallet');
            $this->redirect_page_id = $this->get_option('redirect_page_id');

            $this->init_form_fields();

            global $wpdb;

            if ($wpdb->get_var("SHOW TABLES LIKE '" . $wpdb->prefix . "microwallet_payment_transactions'") === $wpdb->prefix . 'microwallet_payment_transactions') {
                // The database table exist
            } else {
                // Table does not exist
                $query = 'CREATE TABLE IF NOT EXISTS ' . $wpdb->prefix . 'microwallet_payment_transactions (id int(11) unsigned NOT NULL AUTO_INCREMENT, ref varchar(100) not null, trans_code varchar(255) not null,  orderid varchar(100) not null , timestamp datetime default null, PRIMARY KEY (id))';
                $wpdb->query($query);
            }

            // Load the settings.
            $this->init_settings();

            // Define user set variables
            $this->title = sanitize_text_field($this->get_option('title'));
            $this->description = sanitize_text_field($this->get_option('description'));

            $this->microWalletPubicKey = sanitize_text_field($this->get_option('microWalletPubicKey'));
            $this->customerMessage = sanitize_text_field($this->get_option('customerMessage'));
            
            $this->baseTobtc = sanitize_text_field($this->get_option('baseTobtc'));
            
            $this->fixerIoKey = sanitize_text_field($this->get_option('fixerIoKey'));
            
            
            $this->microwallet_render_logo = sanitize_text_field($this->get_option('microwallet_render_logo'));

            add_action('woocommerce_receipt_microwallet_gateway', array($this, 'receipt_page'));
            add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));

            // Payment listener/API hook
            add_action('woocommerce_api_wc_microwallet_gateway', array($this, 'check_microwallet_response'));


            if($this->microwallet_render_logo == "yes") {
                $this->icon = apply_filters('woocommerce_microwallet_icon', plugins_url('img/microwallet.png', __FILE__));
            }
            
            
        }

        /**
         * Admin Panel Options
         * */
        public function admin_options()
        {
            echo '<h3>' . __('Microwallet Payment Gateway', 'microwallet') . '</h3>';
            echo '<p>' . __('Microwallet Payment Gateway allows you to accept payment through various cryptocurrency.', 'microwallet') . '</p>';

            echo '<table class="form-table">';
            $this->generate_settings_html();
            echo '</table>';
        }

        /**
         * Initialise Gateway Settings Form Fields
         * */
        function init_form_fields()
        {
           // $this->save_base_currency_to_btc();
           
            $this->form_fields = array(
                'enabled' => array(
                    'title' => __('Enable/Disable', 'microwallet'),
                    'type' => 'checkbox',
                    'label' => __('Enable Microwallet Payment Gateway', 'microwallet'),
                    'description' => __('Enable or disable the gateway.', 'microwallet'),
                    'desc_tip' => true,
                    'default' => 'yes',
                ),
                'title' => array(
                    'title' => __('Title', 'microwallet'),
                    'type' => 'text',
                    'description' => __('This controls the title which the user sees during checkout.', 'microwallet'),
                    'desc_tip' => false,
                    'default' => __('Pay with Microwallet', 'microwallet'),
                ),
                'description' => array(
                    'title' => __('Description', 'microwallet'),
                    'type' => 'textarea',
                    'description' => __('This controls the description which the user sees during checkout.', 'microwallet'),
                    'default' => __('Pay Via Microwallet: Accepts  Bitcoin.', 'microwallet'),
                ),
                'microwallet_render_logo' => array(
                    'title' => __('Display the logo of Microwallet', 'microwallet'),
                    'type' => 'checkbox',
                    'description' => __('Enable to display the logo of Microwallet next to the title which the user sees during checkout.', 'microwallet'),
                    'default' => 'yes'
                ),
                'microWalletPubicKey' => array(
                    'title' => __('Microwallet Public Key', 'microwallet'),
                    'type' => 'text',
                    'description' => __('Enter Your Microwallet Public Key, this can be gotten on your account page when you login on Microwallet', 'microwallet'),
                    'default' => '',
                    'desc_tip' => true,
                ),

                'microWalletPrivateKey' => array(
                    'title' => __('Microwallet Private key', 'microwallet'),
                    'type' => 'password',
                    'description' => __('Enter Your Microwallet Private key, this can be gotten on your account page when you login on Microwallet', 'microwallet'),
                    'default' => '',
                    'desc_tip' => true,
                ),
                
                'fixerIoKey' => array(
                    'title' => __('FixerIo Key', 'microwallet'),
                    'type' => 'text',
                    'description' => __('Enter current FixerIo Key ', 'microwallet'),
                    'default' => '',
                    'desc_tip' => true,
                ),
                
                'baseTobtc' => array(
                    'title' => __('Currency Rate into BTC', 'microwallet'),
                    'type' => 'text',
                    'description' => __('Enter current currency into BTC ', 'microwallet'),
                    'default' => '',
                    'desc_tip' => true,
                ),

                'redirect_page_id' => array(
                    'title' => __('Return page URL <br />(Successful or Failed Transactions)', 'microwallet'),
                    'type' => 'select',
                    'options' => $this->microwallet_get_pages('Select Page'),
                    'description' => __('We recommend you to select the default “Thank You Page”, in order to automatically serve both successful and failed transactions, with the latter also offering the option to try the payment again.<br /> If you select a different page, you will have to handle failed payments yourself by adding custom code.', 'microwallet'),
                    'default' => "-1"
                )
            );
        }

        public function get_option($key, $empty_value = null)
        {
            $option_value = parent::get_option($key, $empty_value);

            return $option_value;
        }

        function microwallet_get_pages($title = false, $indent = true)
        {
            $wp_pages = get_pages('sort_column=menu_order');
            $page_list = array();
            if ($title) {
                $page_list[] = $title;
            }

            foreach ($wp_pages as $page) {
                $prefix = '';
                // show indented child pages?
                if ($indent) {
                    $has_parent = $page->post_parent;
                    while ($has_parent) {
                        $prefix .= ' - ';
                        $next_page = get_page($has_parent);
                        $has_parent = $next_page->post_parent;
                    }
                }
                // add to page list array array
                $page_list[$page->ID] = $prefix . $page->post_title;
            }
            $page_list[-1] = __('Thank you page', 'microwallet');
            return $page_list;
        }

        /**
         * Returns redirect URL post payment processing
         * @return string redirect URL
         */
        private function getRedirectUrl()
        {
            return add_query_arg( 'wc-api', 'wc_microwallet_gateway', trailingslashit( get_home_url() ) );
        }

        /**
         * Generate the VivaPay Payment button link
         * */
        function generate_microwallet_form($order_id)
        {
            global $woocommerce;

            $order = new WC_Order($order_id);

            $requesturl = 'https://microwallet.co/api/v3/checkouts';

            $publicKey = $this->microWalletPubicKey;
            
            $baseToBtc = $this->baseTobtc;

            $amount = $order->get_total()* $baseToBtc; // Amount in cents

            $merchantTrns = 'Order #'. $order_id;

            $redirectUrl = $this->getRedirectUrl();
            $cancel_url = wc_get_checkout_url();


            $sendDataToMicrowallet = [
                "name"=> $order->billing_first_name,
                "description"=> $merchantTrns,
                "currency"=> 'BTC',
                "amount" => $amount,
                "metadata" => [
                    "param_1"=> $order_id
                ],
                "redirect_url"=> $redirectUrl.'&order_id='.$order_id,
                "cancel_url"=> $cancel_url
            ];

            $sendDataToMicrowallet = json_encode($sendDataToMicrowallet);

            $session = curl_init($requesturl);
            curl_setopt($session, CURLOPT_POST, true);
            curl_setopt($session, CURLOPT_POSTFIELDS, $sendDataToMicrowallet);
            curl_setopt($session, CURLOPT_SSL_VERIFYPEER, true);
            curl_setopt($session, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($session, CURLOPT_TIMEOUT, 1500);
            curl_setopt($session, CURLOPT_CUSTOMREQUEST, 'POST');

            curl_setopt($session, CURLOPT_HTTPHEADER, [
                'X-MW-PUBLIC-KEY: '.$publicKey,
                'Content-Type:application/json'
            ]);

            $response = curl_exec($session);

            $error = curl_error($session);
            curl_close($session);


            try {
                if (is_array(json_decode($response, true))) {
                    $response = json_decode($response, true);

                } else {
                    $order->add_order_note(__("Wrong Merchant crendentials or API unavailable.", 'microwallet') . print_r(array($error, $response), 1));
                    return __("Wrong Merchant crendentials or API unavailable", 'microwallet');
                }
            } catch (Exception $e) {
                //  echo $e->getMessage();
            }

            global $wpdb;

            if (isset($response['code'])) {
                $wpdb->delete($wpdb->prefix . 'microwallet_payment_transactions', array('orderid' => $order_id));
                $wpdb->insert($wpdb->prefix . 'microwallet_payment_transactions', array('trans_code' => $response['code'], 'orderid' => $order_id, 'timestamp' => current_time('mysql', 1)));

                wc_enqueue_js('
                    $.blockUI({
                            message: "' . esc_js(__('Thank you for your order. We are now redirecting you to Microwallet to make payment.', 'microwallet')) . '",
                            baseZ: 99999,
                            overlayCSS:
                            {
                                background: "#fff",
                                opacity: 0.6
                            },
                            css: {
                                padding:        "20px",
                                zindex:         "9999999",
                                textAlign:      "center",
                                color:          "#555",
                                border:         "3px solid #aaa",
                                backgroundColor:"#fff",
                                cursor:         "wait",
                                lineHeight:		"24px",
                            }
                        });
                    jQuery("#submit_microwallet_payment_form").click();
                ');

                return '<form action="' . $response["hosted_link"] . '" method="GET" id="microwallet_payment_form" target="_top">

					<!-- Button Fallback -->
					<div class="payment_buttons">
						<input type="submit" class="button alt" id="submit_microwallet_payment_form" value="' . __('Pay via Microwallet', 'microwallet') . '" /> <a class="button cancel" href="' . esc_url($order->get_cancel_order_url()) . '">' . __('Cancel order &amp; restore cart', 'microwallet') . '</a>
					</div>
					<script type="text/javascript">
						jQuery(".payment_buttons").hide();
					</script>
				</form>';
            } else {
                return __('Wrong Merchant Credentials or SourceID', 'microwallet');
            }
        }


        /**
         * Process the payment and return the result
         * */
        /**/
        function process_payment($order_id)
        {

            $order = new WC_Order($order_id);
            $current_version = get_option( 'woocommerce_version', null );
            if (version_compare( $current_version, '2.2.0', '<' )) { //older version
                return array('result' => 'success', 'redirect' => add_query_arg('order', $order->id, add_query_arg('key', $order->order_key, get_permalink(woocommerce_get_page_id('pay')))));
            } else if (version_compare( $current_version, '2.4.0', '<' )) { //older version
                return array
                (
                    'result' => 'success',
                    'redirect'	=> add_query_arg('order-pay', $order->id, add_query_arg('key', $order->order_key, get_permalink(woocommerce_get_page_id('pay'))))
                );
            } else if (version_compare( $current_version, '3.0.0', '<' )) { //older version
                return array
                (
                    'result' => 'success',
                    'redirect'	=> add_query_arg('order-pay', $order->id, add_query_arg('key', $order->order_key, wc_get_page_permalink( 'checkout' )))
                );
            } else {
                return array('result' => 'success',
                    'redirect' => add_query_arg('order-pay', $order->get_id(), add_query_arg('key', $order->get_order_key(), wc_get_page_permalink('checkout'))));
            }
        }

        /**
         * Output for the order received page.
         * */
        function receipt_page($order)
        {
            echo '<p>' . __('Thank you - your order is now pending payment. You should be automatically redirected to Microwallet to make payment.', 'microwallet') . '</p>';
            echo $this->generate_microwallet_form($order);
        }


        function check_microwallet_cancel_response(){

            global $woocommerce;
            global $wpdb;
            $orderId = sanitize_text_field($_GET['order_id']);

            $orderquery = "SELECT * FROM " . $wpdb->prefix . "microwallet_payment_transactions WHERE `orderid` = " . $orderId . "	;";

            $order = $wpdb->get_results($orderquery);

            $checkoutCode = sanitize_text_field($order[0]->trans_code);

            $requesturl = 'https://microwallet.co/api/v3/checkouts';
            $request = $requesturl . '/' . $checkoutCode.'/cancel';

            $publicKey = $this->microWalletPubicKey;

            $session = curl_init($request);
            curl_setopt($session, CURLOPT_POST, true);
            curl_setopt($session, CURLOPT_POSTFIELDS, []);
            curl_setopt($session, CURLOPT_SSL_VERIFYPEER, true);
            curl_setopt($session, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($session, CURLOPT_TIMEOUT, 1500);
            curl_setopt($session, CURLOPT_CUSTOMREQUEST, 'POST ');
            curl_setopt($session, CURLOPT_HTTPHEADER, [
                'X-MW-PUBLIC-KEY: '.$publicKey,
                'Content-Type:application/json'
            ]);

            // Do the GET and then close the session
            $response = curl_exec($session);

            curl_close($session);

            try {
                if (is_array(json_decode($response, true))) {
                    $response = json_decode($response, true);
                } else {
                    return __("Wrong Merchant credentials or API unavailable", 'microwallet');
                }
            } catch (Exception $e) {
                // echo $e->getMessage();
            }

            $orderquery = "SELECT * FROM " . $wpdb->prefix . "microwallet_payment_transactions WHERE `trans_code` = " . $response['code'] . "	;";

            $order = $wpdb->get_results($orderquery);

            $orderid = sanitize_text_field($order[0]->orderid);
            $order = new WC_Order($orderid);

            $message_type = 'error';

            //Add Admin Order Note
            $order->add_order_note('Payment cancelled by user');

            $microwallet_message = array(
                'message' => 'Payment cancelled by user',
                'message_type' => $message_type,
            );

            $this->generic_add_meta($orderid, 'microwallet_message', $microwallet_message);

            wp_redirect( wc_get_checkout_url() );
            exit;
        }


        function check_microwallet_response()
        {
            global $woocommerce;
            global $wpdb;
            $orderId = sanitize_text_field($_GET['order_id']);

            $order = new WC_Order($orderId);

            if ($order->needs_payment() === false)
            {
                $this->redirectUser($order);
            }

            $orderquery = "SELECT * FROM " . $wpdb->prefix . "microwallet_payment_transactions WHERE `orderid` = " . $orderId . "	;";

            $orderqueryData = $wpdb->get_results($orderquery);

            $checkoutCode = sanitize_text_field($orderqueryData[0]->trans_code);

            $requesturl = 'https://microwallet.co/api/v3/checkouts';
            $request = $requesturl . '/' . $checkoutCode;

            $publicKey = $this->microWalletPubicKey;

            // Get the curl session object
            $session = curl_init($request);

            curl_setopt($session, CURLOPT_POST, true);
            curl_setopt($session, CURLOPT_POSTFIELDS, []);
            curl_setopt($session, CURLOPT_SSL_VERIFYPEER, true);
            curl_setopt($session, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($session, CURLOPT_TIMEOUT, 1500);
            curl_setopt($session, CURLOPT_CUSTOMREQUEST, 'GET');
            curl_setopt($session, CURLOPT_HTTPHEADER, [
                'X-MW-PUBLIC-KEY: '.$publicKey,
                'Content-Type:application/json'
            ]);

            // Do the GET and then close the session
            $response = curl_exec($session);
            curl_close($session);

            try {
                if (is_array(json_decode($response, true))) {
                    $response = json_decode($response, true);
                } else {
                    return __("Wrong Merchant credentials or API unavailable", 'microwallet');
                }
            } catch (Exception $e) {
                // echo $e->getMessage();
            }
            $microwalletTxId = null;
            if (isset($response['code'])) {
                $orderquery = "SELECT * FROM " . $wpdb->prefix . "microwallet_payment_transactions WHERE `trans_code` = " . $response['code'] . "	;";

                $orderqueryData = $wpdb->get_results($orderquery);

                $orderid = sanitize_text_field($order[0]->orderid);
                $order = new WC_Order($orderid);

                $transactionList = $response['transactions'];

                $transactionIds = [];
                if(!empty($transactionList)){
                    foreach($transactionList as $mTransaction){

                        if(($mTransaction['status'] == 1 || strtoupper($mTransaction['status']) == 'SUCCESS') && $mTransaction['amount']['value'] >= $order->get_total()){
                            $transactionIds[] = $mTransaction['hash'];
                        }
                    }
                }


                if(!empty($transactionIds)) {
                    $microwalletTxId = implode(',', $transactionIds);
                    $success = true;


                } else {
                    $error = "Payment no received";
                    $success = false;
                }
            }else{
                $error = "Payment no received";
                $success = false;
            }


            $this->updateOrder($order, $success, $error, $microwalletTxId, null);
            $this->redirectUser($order);

        }

        protected function redirectUser($order)
        {
            $redirectUrl = $this->get_return_url($order);
            wp_redirect($redirectUrl);
            exit;
        }


        /**
         * Modifies existing order and handles success case
         *
         * @param $success, & $order
         */
        public function updateOrder(& $order, $success, $errorMessage, $transactionId)
        {
            global $woocommerce;

            $orderId = $order->get_order_number();

            if (($success === true) and ($order->needs_payment() === true))
            {
                $this->msg['message'] = 'Your payment is successfull' . "&nbsp; Order Id: $orderId";
                $this->msg['class'] = 'success';

                $order->payment_complete($transactionId);
                $order->add_order_note("Microwallet payment successful <br/>Microwallet Id: $transactionId");

                if (isset($woocommerce->cart) === true)
                {
                    $woocommerce->cart->empty_cart();
                }
            }
            else
            {
                $this->msg['class'] = 'error';
                $this->msg['message'] = $errorMessage;

                $order->add_order_note("Transaction Failed: $errorMessage<br/>");
                $order->update_status('failed');
            }

            $this->add_notice($this->msg['message'], $this->msg['class']);

        }

        protected function handleErrorCase(& $order)
        {
            $orderId = $order->get_order_number();

            $this->msg['class'] = 'error';
            $this->msg['message'] = $this->getErrorMessage($orderId);
        }

        protected function getErrorMessage($orderId)
        {
            // We don't have a proper order id
            if ($orderId !== null)
            {
                $message = 'An error occured while processing this payment';
            }
            if (isset($_POST['error']) === true)
            {
                $error = $_POST['error'];

                $description = htmlentities($error['description']);
                $code = htmlentities($error['code']);

                $message = 'An error occured. Description : ' . $description . '. Code : ' . $code;

                if (isset($error['field']) === true)
                {
                    $fieldError = htmlentities($error['field']);
                    $message .= 'Field : ' . $fieldError;
                }
            }
            else
            {
                $message = 'An error occured. Please contact administrator for assistance';
            }

            return $message;
        }

        /**
        * Add a woocommerce notification message
        *
        * @param string $message Notification message
        * @param string $type Notification type, default = notice
        */
        protected function add_notice($message, $type = 'notice')
        {
            global $woocommerce;
            $type = in_array($type, array('notice','error','success'), true) ? $type : 'notice';
            // Check for existence of new notification api. Else use previous add_error
            if (function_exists('wc_add_notice'))
            {
                wc_add_notice($message, $type);
            }
            else
            {
                // Retrocompatibility WooCommerce < 2.1
                switch ($type)
                {
                    case "error" :
                        $woocommerce->add_error($message);
                        break;
                    default :
                        $woocommerce->add_message($message);
                        break;
                }
            }
        }
        

        
    }


    function microwallet_message()
    {
        $order_id = absint(get_query_var('order-received'));
        $order = new WC_Order($order_id);
        if (method_exists($order, 'get_payment_method')) {
            $payment_method = $order->get_payment_method();
        } else {
            $payment_method = $order->payment_method;
        }

        if (is_order_received_page() && ('microwallet_gateway' == $payment_method)) {

            $vivapayments_message = ''; //get_post_meta($order_id, '_papaki_vivapayments_message', true);
            if (method_exists($order, 'get_meta')) {
                $vivapayments_message = $order->get_meta('microwallet_message', true);
            } else {
                $vivapayments_message = get_post_meta($order_id, 'microwallet_message', true);
            }
            if (!empty($vivapayments_message)) {
                $message = $vivapayments_message['message'];
                $message_type = $vivapayments_message['message_type'];

                //delete_post_meta($order_id, '_papaki_vivapayments_message');
                if (method_exists($order, 'delete_meta_data')) {
                    $order->delete_meta_data('microwallet_message');
                    $order->save_meta_data();
                } else {
                    delete_post_meta($order_id, 'microwallet_message');
                }

                wc_add_notice($message, $message_type);
            }
        }
    }

    add_action('wp', 'microwallet_message');


    /**
     * Add Vivapay Gateway to WC
     * */
    function woocommerce_add_microwallet_gateway($methods)
    {
        $methods[] = 'WC_Microwallet_Gateway';
        return $methods;
    }

    add_filter('woocommerce_payment_gateways', 'woocommerce_add_microwallet_gateway');

    /**
     * Add Settings link to the plugin entry in the plugins menu for WC below 2.1
     * */
    if (version_compare(WOOCOMMERCE_VERSION, "2.1") <= 0) {

        add_filter('plugin_action_links', 'microwallet_plugin_action_links', 10, 2);

        function microwallet_plugin_action_links($links, $file)
        {
            static $this_plugin;

            if (!$this_plugin) {
                $this_plugin = plugin_basename(__FILE__);
            }

            if ($file == $this_plugin) {
                $settings_link = '<a href="' . get_bloginfo('wpurl') . '/wp-admin/admin.php?page=woocommerce_settings&tab=payment_gateways&section=WC_Microwallet_Gateway">Settings</a>';
                array_unshift($links, $settings_link);
            }
            return $links;
        }

    }else {
        add_filter('plugin_action_links', 'microwallet_plugin_action_links', 10, 2);
    }
    
    
    
    
    function microwallet_plugin_action_links($links, $file)
    {
        static $this_plugin;

        if (!$this_plugin) {
            $this_plugin = plugin_basename(__FILE__);
        }

        if ($file == $this_plugin) {
            $settings_link = '<a href="' . get_bloginfo('wpurl') . '/wp-admin/admin.php?page=wc-settings&tab=checkout&section=wc_microwallet_gateway">Settings</a>';
            array_unshift($links, $settings_link);
        }
        return $links;
    }
    
    
    function btcrate_check_every_1_hours( $schedules ) {
        $schedules['btc_every_one_hours'] = array(
            'interval' => 3600,
            'display'  => __( 'BTC Every 1 hours' ),
        );
        return $schedules;
    }
    add_filter( 'cron_schedules', 'btcrate_check_every_1_hours' );
            
    if ( ! wp_next_scheduled( 'save_base_btc_rates' ) ) {
      wp_schedule_event( time(), 'btc_every_one_hours', 'save_base_btc_rates' );
    }


    function save_base_currency_to_btc(){
        global $woocommerce;
        
        $oldOptions = get_option('woocommerce_microwallet_gateway_settings');
      
        $fixerKey = $oldOptions['fixerIoKey'];
        
        $baseCurrency =  get_woocommerce_currency();
        

        $curl = curl_init();
        
        curl_setopt_array($curl, array(
          CURLOPT_URL => 'http://data.fixer.io/api/latest?access_key='.$fixerKey,
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'GET',
          
        ));
        
        $response = curl_exec($curl);
        
        curl_close($curl);
        
         try {
            if (is_array(json_decode($response, true))) {
                $response = json_decode($response, true);
                
                if(isset($response['rates'][$baseCurrency]) && isset($response['rates']['BTC'])){
                  
                    $baseCurrencyValue = $response['rates'][$baseCurrency];
                    $btcValue = $response['rates']['BTC'];
                    
                    
                    
                    $baseCurrencyIntoBtc = ($btcValue / $baseCurrencyValue);
                    
                    
                   $baseCurrencyIntoBtc =  sprintf('%f', floatval($baseCurrencyIntoBtc));
                    
                    
                    
                    $oldOptions['baseTobtc'] = $baseCurrencyIntoBtc;
                    
                    
                    update_option( 'woocommerce_microwallet_gateway_settings', $oldOptions );
                }
            }
        } catch (Exception $e) {
        }
    }
    add_action( 'save_base_btc_rates', 'save_base_currency_to_btc' );
    
}

